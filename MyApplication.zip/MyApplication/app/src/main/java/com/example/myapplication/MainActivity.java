package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;



import android.content.Intent;
import android.view.View;



public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private CardView chatCard, newsCard, moreCard, feedbackCard, addCard ;
    //LinearLayout ll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);

        chatCard  = findViewById(R.id.chart_card);
        newsCard  =  findViewById(R.id.news_card);
        moreCard  = findViewById(R.id.add_card);
        feedbackCard  = findViewById(R.id.feedback_card);
        addCard  = findViewById(R.id.add_card);

        //adding a click listener
        chatCard.setOnClickListener(this);
        newsCard.setOnClickListener(this);
        addCard.setOnClickListener(this);
        moreCard.setOnClickListener(this);
        addCard.setOnClickListener(this);



//        ll = findViewById(R.id.ll);
//        mycard = findViewById(R.id.bankcardId);
//        i = new Intent(this,ae.class);
//        mycard.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(i);
//            }
//        });

    }

    @Override
    public void onClick(View v){
        Intent intent;

        switch ((v.getId())){
            case R.id.chart_card:
                intent = new Intent(this, Chat.class);
                startActivity(intent);
                break;

            case R.id.feedback_card:
                intent = new Intent(this, Feedback.class);
                startActivity(intent);
                break;

            case R.id.news_card:
                intent = new Intent(this, News.class);
                startActivity(intent);
                break;

            case R.id.more_card:
                intent = new Intent(this, MoreInfo.class);
                startActivity(intent);
                break;

            case R.id.add_card:
                intent = new Intent(this, AddMore.class);
                startActivity(intent);
                break;

             default:
                 break;
        }

    }
}